contexts switching이 필요한 이유

hyper threading: 하나의 코어에서 몇개 동시 처리 가능

synchroized 키워드

데드락 해결방법 리서칭

병목은 어떻게 처리하면 될까?

대칭키 암호화방식

비대칭키 암호화방식
=> 단점! 조금 더 무겁다
(복호화 시간이 많이 든다.)

https / ssl 구체적으로
완벽하게 설명!

reponse의 구조

content negotiation (컨텐츠 협상)

로그인 유지?
    session cookie / persistence cookie


1. 쿠키란 ? session cookie방식과 persistence cookie를 비교해주세요.

2. SSL Handshaking 방식 및 대칭 / 비대칭키 암호화 방식에 대해 설명해주세요.